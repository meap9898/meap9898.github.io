package simulation;

import javafx.scene.image.Image;

import static simulation.World.*;

/**
 * This class represents a sheep. The logic is only partially implemented.
 *
 * @author Mr. Smithe
 */
public class Sheep extends Animal{

    //all sheep share one image.
    private static final Image sheepImage = new Image("images/sheep.png");

    /**
     * Constructor for Sheep.
     *
     * @param world this Sheep's world
     * @param x the x-coordinate
     * @param y the y-coordinate
     */
    public Sheep(World world, int x, int y) {
        super(world, x, y, sheepImage);
    }

    /**
     * Sheep eat grass. If there is no grass at the current location, they move on.
     * @param age the age of the sheep
     * @param grasseaten tracks how much is eaten
     */
    int grasseaten = 0;
    int age = 0;
    @Override

    public void act() {
        //try to eat grass
        /**
         * this tracks if a sheep has eaten grass
         * and counts the age and grass eaten and if a sheep has eaten enough for a baby
         */
        Grass grass = (Grass) getWorld().getOneEntityAt(getX(), getY(), Grass.class);
        if(grass != null){
            System.out.println(this + " just ate " + grass);
            getWorld().remove(grass);
            grasseaten = grasseaten + 1;
            System.out.println(grasseaten);
            if(grasseaten == 5){
                int x = getX();
                int y = getY();
                new Sheep(getWorld(),x,y);
                System.out.println(this + "Had a baby!");
                grasseaten = 0;
                age = age + 1;
            }
            //TODO add health
        }
        else{
            age = age + 1;
            if (age > 100)
            {
                getWorld().remove(this);
                System.out.println(this + "dead");
            }
           super.act();

            //TODO maybe seek out grass?
            //TODO prevent sheep from wandering off the world.
        }
    }

    /**
     * Returns a String representation of this Sheep.
     *
     * @return a String representation of this Sheep
     */
    @Override
    public String toString() {
        return "Sheep{" + super.toString() + "}";
    }
}
