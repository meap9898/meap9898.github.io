package simulation;

import javafx.scene.image.Image;

/**
 * This class represents a sheep. The logic is only partially implemented.
 *
 * @author Mr. Smithe
 */
public class Wolf extends Animal{

    private static final Image wolfImage = new Image("images/wolf.png");

    /**
     * Constructor for Wolfs
     *
     * @param world this Wolf's world
     * @param x the x-coordinate
     * @param y the y-coordinate
     */
    public Wolf(World world, int x, int y) {
        super(world, x, y, wolfImage);
    }

    /**
     * Wolf eat Sheep. If there is no grass at the current location, they move on.
     * @param sheepeaten tracks how many sheep have been eaten
     * @param health tracks the hunger of the wolf
     *  @param age track the age of the wolf
     */
    int sheepeaten = 0;
    int health = 60;
    int age = 0;
    @Override
    public void act() {
        //try to eat sheep
        Sheep sheep = (Sheep) getWorld().getOneEntityAt(getX(), getY(), Sheep.class);
        if(sheep != null){
            System.out.println(this + " just ate " + sheep);
            getWorld().remove(sheep);
            health = 60;
            sheepeaten = sheepeaten + 1;
            if(sheepeaten == 2) {
                int x = getX();
                int y = getY();
                new Wolf(getWorld(), x, y);
                sheepeaten = 0;
                age = age + 1;
            }
            //TODO add health
        }else{
            age = age + 1;
            if (age > 100)
            {
                getWorld().remove(this);
                System.out.println(this + "dead");
            }
            health = health - 1;
            if (health == 0){
                getWorld().remove(this);
            }
            super.act();
            //TODO maybe seek out sheep?
            //TODO prevent sheep from wandering off the world.
        }
    }

    /**
     * Returns a String representation of this Wolf.
     *
     * @return a String representation of this Wolf.
     */
    @Override
    public String toString() {
        return "Wolf{" + super.toString() + "}";
    }
}
