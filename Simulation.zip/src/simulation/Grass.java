package simulation;

import javafx.scene.image.Image;

import static simulation.World.*;
import static simulation.World.CELL_SIZE;

/**
 * This class represents grass. Grass can spread to neighbouring tiles.
 *
 * @author Mr. Smithe
 */
public class Grass extends Entity {

    //all grass share one image
    private static final Image grassImage = new Image("images/grass.png");

    /**
     * Construct a new Grass object in the given world, at the given location.
     *
     * @param world the World where this grass will live.
     * @param x the x-coordinate of the grass
     * @param y the y-coordinate of the grass
     */
    public Grass(World world, int x, int y) {
        super(world, x, y, grassImage);
    }

    /**
     * Grass might grow.
     */
    @Override
    public void act(){
        //grass has a 5% chance to spread to a neighbouring tile.
        if(Simulator.getRandomInt(1, 50) == 1){
            int x = getX();
            int y = getY();
            switch (Simulator.getRandomInt(0, 3)){
                case 0: x++; break;
                case 1: y++; break;
                case 2: x--; break;
                case 3: y--; break;
            }
            if (x >= (MAX_WIDTH / CELL_SIZE))
            {
                x = (MAX_WIDTH / CELL_SIZE) - 1;
            }
            if(y >= (MAX_HEIGHT/CELL_SIZE)){
                y = (MAX_HEIGHT/CELL_SIZE) - 1;
            }
            if(x < 0){
                x = 0;
            }
            if(y <0){
                y = 0;
            }
            //TODO maybe make sure there isn't already grass there?
            new Grass(getWorld(), x, y);
        }
    }

    /**
     * Returns a String representation of this Grass Object.
     *
     * @return the String representation of this Grass
     */
    @Override
    public String toString() {
        return "Grass{" + super.toString() + "}";
    }
}
