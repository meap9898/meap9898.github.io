package simulation;

import javafx.scene.image.Image;

import static simulation.World.*;
import static simulation.World.CELL_SIZE;

/**
 * This class represents an Animal.
 *
 * @author Mr. Smithe
 */


public class Animal extends Entity{
    /**
     * Constructor for animals.
     */
    public void act() {
        //move to greener pastures

        int x = getX();
        int y = getY();

        switch (Simulator.getRandomInt(0, 3)){
            case 0: x++; break;
            case 1: y++; break;
            case 2: x--; break;
            case 3: y--; break;
        }
        if (x >= (MAX_WIDTH / CELL_SIZE))
        {
            x = (MAX_WIDTH / CELL_SIZE) - 1;
        }
        if(y >= (MAX_HEIGHT/CELL_SIZE)){
            y = (MAX_HEIGHT/CELL_SIZE) - 1;
        }
        if(x < 0){
            x = 0;
        }
        if(y <0){
            y = 0;
        }
        moveTo(x, y);

        //TODO maybe seek out grass?
        //TODO prevent sheep from wandering off the world.
    }


    public Animal(World world, int x, int y, Image image) {
        super(world, x, y, image);
    }

}
