package simulation;

import javafx.scene.Group;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;

import java.util.ArrayList;

/**
 * This class represents a World.
 *
 * @author Mr. Smithe
 */
public class World {

    Group root = new Group();

    //a flexible array that doesn't have to have a fixed length.
    private ArrayList<Entity> entities = new ArrayList<Entity>();

    //the map is made up of a grid of squares.
    private Rectangle[][] map = new Rectangle[MAX_WIDTH / CELL_SIZE][MAX_HEIGHT / CELL_SIZE];

    //dimensions of our world
    public static final int MAX_WIDTH = 800;
    public static final int MAX_HEIGHT = 800;
    public static final int CELL_SIZE = 50;

    /**
     * Constructs the World.
     */
    public World(){
        for(int i = 0; i < map.length; i++){
            for(int j = 0; j < map[i].length; j++){
                Rectangle rectangle = new Rectangle(CELL_SIZE, CELL_SIZE);
                rectangle.setX(i * CELL_SIZE);
                rectangle.setY(j * CELL_SIZE);

                rectangle.setFill(Color.GREEN);
                // uncomment to show the grid
                // rectangle.setStroke(Color.BLACK);

                map[i][j] = rectangle;
                root.getChildren().add(rectangle);
            }
        }
    }

    /**
     * Calls the act method of each Entity currently in the World.
     */
    public void act() {
        //create a copy of current actors so that new actors created this turn don't get to act.
        //also, the state of the list cannot change while this loop is executing.
        ArrayList<Entity> currentEntities = (ArrayList<Entity>) entities.clone();
        for(Entity e : currentEntities){
            e.act();
        }
    }

    /**
     * Adds an Entity to this World.
     *
     * @param entity the Entity to add
     */
    public void add(Entity entity){
        entities.add(entity);
        root.getChildren().add(entity.getNode());
    }

    /**
     * Removes a given Entity from the World.
     *
     * @param entity the Entity to remove
     */
    public void remove(Entity entity){
        entities.remove(entity);
        root.getChildren().remove(entity.getNode());
    }

    /**
     * Returns a list of all entities at a given location.
     *
     * @param x the x-coordinate
     * @param y the y-coordinate
     * @return the List of Entities
     */
    public ArrayList<Entity> getEntitiesAt(int x, int y) {
        ArrayList<Entity> answer = new ArrayList<Entity>();

        for(Entity entity : entities){
            if(entity.getX() == x && entity.getY() == y){
                answer.add(entity);
            }
        }

        return answer;
    }

    /**
     * Gets all Entities of a specific type at a given location.
     *
     * @param x the x-coordinate
     * @param y the y-coordinate
     * @param c The Class of Entity we are looking for
     * @return The list of Entities
     */
    public ArrayList<Entity> getEntitiesAt(int x, int y, Class c) {
        ArrayList<Entity> answer = new ArrayList<Entity>();

        for(Entity entity : entities){
            if(entity.getClass() == c && entity.getX() == x && entity.getY() == y){
                answer.add(entity);
            }
        }

        return answer;
    }

    /**
     * Returns the first Entity at the given location of the given type.
     *
     * @param x the x-coordinate
     * @param y the y-coordinate
     * @param c the class of the Entity we are looking for
     * @return the Entity, if one exists. null otherwise.
     */
    public Entity getOneEntityAt(int x, int y, Class c){
        for(Entity entity : entities){
            if(entity.getClass() == c && entity.getX() == x && entity.getY() == y){
                return entity;
            }
        }
        return null;
    }

    /**
     * Returns the container for all visuals of this World.
     *
     * @return the root node
     */
    public Group getRoot(){
        return root;
    }
}
