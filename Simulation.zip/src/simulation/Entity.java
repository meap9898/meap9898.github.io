package simulation;

import javafx.animation.TranslateTransition;
import javafx.scene.Node;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.util.Duration;

/**
 * This class handles a lot of the logic for any type of Object that might live in our world.
 *
 * @author Mr. Smithe
 */
public class Entity {
    //instance variables
    private World world;

    private int x;
    private int y;

    private Image image; //the image just points to the file
    private ImageView imageView; //this is the visual part

    //this handles smooth movement from one tile to the next.
    private TranslateTransition mover;



    /**
     * Create a new Entity. This will also add this Entity to the world and set the image.
     *this is runs once per second
     * @param world the world this Entity lives in
     * @param x the x-coordinate of this Entity
     * @param y the y-coordinate of this Entity
     * @param image the image that represents this Entity
     */
    public Entity(World world, int x, int y, Image image){
        this.world = world;
        this.image = image;
        this.x = x;
        this.y = y;
        imageView = new ImageView(image);
        imageView.setX(x * World.CELL_SIZE);
        imageView.setY(y * World.CELL_SIZE);

        mover = new TranslateTransition(Duration.millis(500), imageView);
        mover.setCycleCount(1);

        world.add(this);
    }

    /**
     * This method is called by the World class once per second.
     *
     * This method should be overridden by any child classes.
     */
    public void act() {

    }

    /**
     * Animates the Entity moving to the given location in half a second.
     *
     * @param x the new x-coordinate
     * @param y the new y-coordinate
     */
    public void moveTo(int x, int y){
        //set the location to move to
        mover.setByX((x - this.x) * World.CELL_SIZE);
        mover.setByY((y - this.y) * World.CELL_SIZE);

        //animate the movement
        mover.play();

        //update coordinates
        this.x = x;
        this.y = y;
    }

    /**
     * Returns the visual component of this Entity.
     *
     * @return the visual component of this Entity
     */
    public Node getNode() {
        return imageView;
    }

    /**
     * Returns the current x-coordinate of the Entity.
     *
     * @return the x-coordinate
     */
    public int getX() {
        return x;
    }

    /**
     * Returns the current y-coordinate of the Entity.
     *
     * @return the y-coordinate
     */
    public int getY() {
        return y;
    }

    /**
     * Returns the World that contains this Entity.
     *
     * @return this Entity's World
     */
    public World getWorld(){
        return world;
    }

    /**
     * Returns a String representation of this Entity.
     * @return a String representation of this Entity.
     */
    @Override
    public String toString() {
        return "Entity{x=" + x + ", y=" + y + '}';
    }
}
