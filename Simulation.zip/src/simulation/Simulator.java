package simulation;

import javafx.animation.AnimationTimer;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.util.Random;

/**
 * This class runs our Simulation. It also has some basic helper methods.
 *
 * @author Mr. Smithe
 */
public class Simulator extends Application {

    private static Random random = new Random();

    private World world = new World();
    private long lastRun = 0;

    /**
     * Launches the application.
     *
     * @param args command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }

    /**
     * Sets up the visuals.
     *
     * @param primaryStage the Program's Stage
     */
    @Override

    public void start(Stage primaryStage) {
        //set the scene
        Scene scene = new Scene(world.getRoot(), World.MAX_WIDTH, World.MAX_HEIGHT);

        addRandomGrass(200);
        addRandomSheep(10);
        addRandomWolf(3);


        //this timer calls the act method of the world once per second.
        AnimationTimer at = new AnimationTimer() {
            @Override
            public void handle(long now) {

                //now is in nanoseconds.
                if (now - lastRun > 1000000000) {
                    lastRun = now;
                    world.act();
                }
            }
        };

        at.start();

        primaryStage.setTitle("Simulation");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    /**
     * Adds a given number of Grass objects to random locations within the world.
     *
     * @param n the number of Grass to generate
     */
    public void addRandomGrass(int n){
        //TODO maybe ensure grass doesn't spawn on top of other grass.
        for (int i = 0; i < n; i++){
            int x = getRandomInt(0, World.MAX_WIDTH / World.CELL_SIZE);
            int y = getRandomInt(0, World.MAX_WIDTH / World.CELL_SIZE);

            new Grass(world, x, y);
        }
    }

    /**
     * Adds a given number of Sheep objects to random locations within the world.
     *
     * @param n the number of Sheep to generate
     */
    public void addRandomSheep(int n){
        //TODO maybe ensure sheep don't spawn on top of each other.
        for (int i = 0; i < n; i++){
            int x = getRandomInt(0, World.MAX_WIDTH / World.CELL_SIZE);
            int y = getRandomInt(0, World.MAX_WIDTH / World.CELL_SIZE);

            new Sheep(world, x, y);
        }
    }

    /**
     * Adds a given number of Wolf objects to random location
     * @param n the number of Wolfs
     */
    public void addRandomWolf(int n){
        for (int i = 0; i < n; i++){
            int x = getRandomInt(0, World.MAX_WIDTH / World.CELL_SIZE);
            int y = getRandomInt(0, World.MAX_WIDTH / World.CELL_SIZE);

            new Wolf(world, x, y);
        }
    }

    /**
     * Generates a random number between the given range (inclusive).
     *
     * @param min the minimum number possible to generate
     * @param max the maximum number possible to generate
     * @return a random number within the given range
     */
    public static int getRandomInt(int min, int max){
        if(min > max){
            //ensure parameters are in correct order.
            return getRandomInt(max, min);
        }
        return random.nextInt(max - min + 1) + min;
    }
}
